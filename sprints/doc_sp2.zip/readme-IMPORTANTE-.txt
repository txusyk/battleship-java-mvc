IMPORTANTE

La carpeta contiene:

\
	requisitos_juego.pdf - Contiene las especificaciones del juego

\planif_reuniones
	planificaciónTareas.pdf - Los tiempos reales una vez finalizado el sprint
	actas_reunion.pdf - Contiene todas las actas de reunión de este Sprint

\doc_pruebas
	doc_pruebasUnitarias.pdf - Contiene el análisis de las pruebas 
	resultados_testNG.html - Contiene los resultados de la ejecución de los test

\diagramas
	sec
		disparar_seq_sp2.jpg - Diagrama de disparo
		radar_seq_sp2.jpg - Diagrama de radar
	UML
		uml_sp2 - El UML resultante una vez finalizado el segundo sprint
		
	


IMPORTANTE

La carpeta contiene:

\
	PlanificaciónTareas.pdf - Los tiempos reales una vez finalizado el sprint
	Requisitos_juego.pdf - Contiene las especificaciones del juego
	Actas_reunion.pdf - Contiene todas las actas de reunión de este Sprint

\doc_pruebas
	doc_pruebasUnitarias.pdf - Contiene el análisis de las pruebas 
	resultados_test.html - Contiene los resultados de la ejecución de los test

\diagramas
	sec
		seq1_sp1.jpg - Diagrama principal
		seq1.1_sp1.jpg - Diagrama extra
	UML
		UML_inicial.jpg - El UML base sobre el que comenzamos trabajando
		UML_final.jpg - El UML una vez hemos finalizado el primer Sprint
\reuniones
	

